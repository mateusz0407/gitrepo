

#include <iostream>
using namespace std ;
int main(int argc, char **argv)
{
   int l;   

    for(int i=0;i<=2;i++){

            cout<
            cin>>l;

            if((l>0) &&(l<=12)){

                     cout<<"udalo sie za: " <
                               break;


                               }

                          }
}


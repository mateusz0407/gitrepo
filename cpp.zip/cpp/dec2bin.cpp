/*
 * dec2bin.cpp
 */


#include <iostream>
using namespace std;
int main(int argc, char **argv)
{
	int n = 0;
    int p = 2;
    
	cout<<"Podaj liczbe(dec): ";
    cin>>n;
    cout<<"Podaj podstawe: ";
    cin>>p;
    
	return 0;
}


/*
 * hello.cpp

 */


#include <iostream>
using namespace std;


int main(int argc, char **argv)
{
 //char imie; // deklaracja zminnej znakowej 
; // deklaracja zminnej tablicowej  
 int a , b , c ;
 a =b=c=0;

    cout << "podaj liczby: " << endl;
    cin >> a >> b >> c;
    if (a > b)
{
    if (a>c) cout <<"najwieksze jest a!";
    else cout << "najwieksze jest c";
    } 
    else
    {
    ; // a nie jest większe od b
}
    
    return 0;
}



#include <iostream>
using namespace std;
int main(int argc, char **argv)
{
    for
    (int i=20; i<30; i++)
    cout<<" "<<i<<"";
    return 0;
}


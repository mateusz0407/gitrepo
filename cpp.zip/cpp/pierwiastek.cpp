/*
 * hello.cpp
 */


#include <iostream>
#include <math.h>

using namespace std;

int main(int argc, char **argv)
{

    int r=0;
    

    cout <<"Podaj liczbę: "<<endl;
    cin >> r;
    cout<<"Pierwiastek: = "<<sqrt(r)<<endl;
 
    

	return 0; 
}


#include <iostream>
using namespace std;
int main(int argc, char **argv)
{


	for (int i=10; i <99;i++)
	if (i % 6==0)
	cout<<i<<endl;
	return 0;
}


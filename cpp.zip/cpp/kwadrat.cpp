/*
 * hello.cpp

 */


#include <iostream>
using namespace std;


int main(int argc, char **argv)
{
 //char imie; // deklaracja zminnej znakowej 
; // deklaracja zminnej tablicowej  
 int bok = 0;//deklaracja i inicjacja zmienneej
 
  //inicjacja zmiennej

	cout << "Witaj w C++!!" << endl;
	cout << "podaj bok kwadratu";
    cin >> bok;
    cout<< "obwód:" << 4 * bok << endl;
    cout<< "pole: " << bok* bok << endl;      
    return 0;
}

